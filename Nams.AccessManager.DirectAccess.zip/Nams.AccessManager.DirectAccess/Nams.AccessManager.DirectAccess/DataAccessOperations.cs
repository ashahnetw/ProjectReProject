﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nams.AccessManager.DirectAccess
{
   public class DataAccessOperations
    {

        DatabaseProviderFactory factory = new DatabaseProviderFactory();
        Database db = null;

     public   DataAccessOperations()
        {
            db = factory.Create("Constr1");
        }

        public Dictionary<string, object> PrecessRequestInsert(JObject jobject)
        {
            Dictionary<string, object> IDCOllection = new Dictionary<string, object>();
           
            dynamic dyn = jobject;
            UserProfile up = dyn.data.UserProfile.ToObject<UserProfile>();
            Request req =  dyn.data.Request.ToObject<Request>();
            CoAuthor[] coa = dyn.data.CoAuthors.ToObject<CoAuthor[]>();

            using (DbConnection conn = db.CreateConnection())
            {
                conn.Open();

                DbTransaction tsx = conn.BeginTransaction();
                try
                {
                   
                    int UpID = InsertUserProfile(up, tsx);
                    up.UserProfileID = UpID;
                    IDCOllection.Add("UserProfile", up);

                    req.UserProfileID = UpID;
                    int ReqId = InsertUserRequest(req, tsx);
                    req.RequestID = ReqId;
                   
                    IDCOllection.Add("Request", req);
                    foreach (CoAuthor co in coa )
                    {
                        co.RequestID = ReqId;
                       co.CoAuthorID = InsertUserCoAuthors(co, tsx);
                    }
                    IDCOllection.Add("CoAuthor", coa);

                    tsx.Commit();

                   

                }
                catch
                {
                    tsx.Rollback();
                }

                return IDCOllection;
            }
        }

        public int InsertUserProfile(UserProfile up, DbTransaction tsx)
        {
            //insert into UserProfile values (@fname, @lname); select SCOPE_IDENTITY();
            DbCommand cmd = db.GetSqlStringCommand(SqlResource.Insert_UserProfile);
            List<SqlParameter> paramsList = new List<SqlParameter>();
            paramsList.Add(new SqlParameter("@fname", up.FirstName));
            paramsList.Add(new SqlParameter("@lname", up.LastName));
           
            cmd.Parameters.AddRange(paramsList.ToArray<SqlParameter>());






           object o=  db.ExecuteScalar(cmd, tsx);

            return (o == null) ? 0 : int.Parse(o.ToString());

        }

        public int InsertUserRequest(Request req, DbTransaction tsx)
        {
            //insert into Request values(@reqdesc, @upid); select SCOPE_IDENTITY();
            DbCommand cmd = db.GetSqlStringCommand(SqlResource.Insert_Request);
            List<SqlParameter> paramsList = new List<SqlParameter>();
            paramsList.Add(new SqlParameter("@reqdesc", req.RequestDescription));
            paramsList.Add(new SqlParameter("@upid", req.UserProfileID));

            cmd.Parameters.AddRange(paramsList.ToArray<SqlParameter>());


            

            object o = db.ExecuteScalar(cmd, tsx);

            return (o == null) ? 0 : int.Parse(o.ToString());

        }

        public int InsertUserCoAuthors(CoAuthor coa, DbTransaction tsx)
        {
            //insert into CoAuthors values(@reqid, @upid,@roleid); select SCOPE_IDENTITY();
            DbCommand cmd = db.GetSqlStringCommand(SqlResource.Insert_CoAuthors);
            List<SqlParameter> paramsList = new List<SqlParameter>();
            paramsList.Add(new SqlParameter("@reqid", coa.RequestID));
            paramsList.Add(new SqlParameter("@upid", coa.UserProfileID));
            paramsList.Add(new SqlParameter("@roleid", coa.RoleID));
            cmd.Parameters.AddRange(paramsList.ToArray<SqlParameter>());




            object o = db.ExecuteScalar(cmd, tsx);

            return (o == null) ? 0 : int.Parse(o.ToString());

        }


    }
}
