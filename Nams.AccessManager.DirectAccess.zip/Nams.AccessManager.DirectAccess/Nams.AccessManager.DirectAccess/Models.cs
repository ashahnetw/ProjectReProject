﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Nams.AccessManager.DirectAccess
{
   public class UserProfile
    { 
    public int UserProfileID { get; set; }
    public string FirstName { get; set; }
    public string LastName { get; set; }
    }

    public class Request
    {
       public int RequestID { get; set; }
       public string RequestDescription { get; set; }
        public int UserProfileID { get; set; }
    }

  public  class CoAuthor
    {
      public int   CoAuthorID { get; set; }
        public int RequestID { get; set; }
        public int UserProfileID { get; set; }
       public int  RoleID { get; set; }
    }


}