﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Web;

namespace WebAPI.Utilities
{
   
        public class SecureJsonMediaTypeFormatter : JsonMediaTypeFormatter
        {
            public override System.Threading.Tasks.Task WriteToStreamAsync(Type type, object value, System.IO.Stream writeStream, HttpContent content, TransportContext transportContext)
            {
                value = new { data = value };
                return base.WriteToStreamAsync(type, value, writeStream, content, transportContext);
            }
        }
    
}